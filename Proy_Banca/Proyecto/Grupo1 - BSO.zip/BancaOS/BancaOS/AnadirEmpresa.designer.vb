﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AnadirEmpresa
    Inherits EmpresaInicio

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlAdd = New System.Windows.Forms.Panel()
        Me.cmbaccount2 = New System.Windows.Forms.ComboBox()
        Me.cmbaccount1 = New System.Windows.Forms.ComboBox()
        Me.btnclean = New System.Windows.Forms.Button()
        Me.btnreturn = New System.Windows.Forms.Button()
        Me.btnadd = New System.Windows.Forms.Button()
        Me.ckbActivate = New System.Windows.Forms.CheckBox()
        Me.txtbhome = New System.Windows.Forms.TextBox()
        Me.txtbname = New System.Windows.Forms.TextBox()
        Me.lblc2 = New System.Windows.Forms.Label()
        Me.lblc1 = New System.Windows.Forms.Label()
        Me.lvlActivate = New System.Windows.Forms.Label()
        Me.lblhome = New System.Windows.Forms.Label()
        Me.lblname = New System.Windows.Forms.Label()
        Me.txtbcif = New System.Windows.Forms.TextBox()
        Me.lblcif = New System.Windows.Forms.Label()
        Me.lblTittle = New System.Windows.Forms.Label()
        Me.pnlAdd.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlAdd
        '
        Me.pnlAdd.BackColor = System.Drawing.Color.White
        Me.pnlAdd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlAdd.Controls.Add(Me.cmbaccount2)
        Me.pnlAdd.Controls.Add(Me.cmbaccount1)
        Me.pnlAdd.Controls.Add(Me.btnclean)
        Me.pnlAdd.Controls.Add(Me.btnreturn)
        Me.pnlAdd.Controls.Add(Me.btnadd)
        Me.pnlAdd.Controls.Add(Me.ckbActivate)
        Me.pnlAdd.Controls.Add(Me.txtbhome)
        Me.pnlAdd.Controls.Add(Me.txtbname)
        Me.pnlAdd.Controls.Add(Me.lblc2)
        Me.pnlAdd.Controls.Add(Me.lblc1)
        Me.pnlAdd.Controls.Add(Me.lvlActivate)
        Me.pnlAdd.Controls.Add(Me.lblhome)
        Me.pnlAdd.Controls.Add(Me.lblname)
        Me.pnlAdd.Controls.Add(Me.txtbcif)
        Me.pnlAdd.Controls.Add(Me.lblcif)
        Me.pnlAdd.Controls.Add(Me.lblTittle)
        Me.pnlAdd.Location = New System.Drawing.Point(296, 174)
        Me.pnlAdd.Name = "pnlAdd"
        Me.pnlAdd.Size = New System.Drawing.Size(461, 434)
        Me.pnlAdd.TabIndex = 3
        '
        'cmbaccount2
        '
        Me.cmbaccount2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbaccount2.FormattingEnabled = True
        Me.cmbaccount2.Location = New System.Drawing.Point(188, 278)
        Me.cmbaccount2.Name = "cmbaccount2"
        Me.cmbaccount2.Size = New System.Drawing.Size(187, 21)
        Me.cmbaccount2.TabIndex = 17
        '
        'cmbaccount1
        '
        Me.cmbaccount1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbaccount1.FormattingEnabled = True
        Me.cmbaccount1.Location = New System.Drawing.Point(188, 245)
        Me.cmbaccount1.Name = "cmbaccount1"
        Me.cmbaccount1.Size = New System.Drawing.Size(187, 21)
        Me.cmbaccount1.TabIndex = 16
        '
        'btnclean
        '
        Me.btnclean.Location = New System.Drawing.Point(300, 328)
        Me.btnclean.Name = "btnclean"
        Me.btnclean.Size = New System.Drawing.Size(75, 23)
        Me.btnclean.TabIndex = 15
        Me.btnclean.Text = "Limpiar"
        Me.btnclean.UseVisualStyleBackColor = True
        '
        'btnreturn
        '
        Me.btnreturn.Location = New System.Drawing.Point(90, 328)
        Me.btnreturn.Name = "btnreturn"
        Me.btnreturn.Size = New System.Drawing.Size(75, 23)
        Me.btnreturn.TabIndex = 14
        Me.btnreturn.Text = "Volver"
        Me.btnreturn.UseVisualStyleBackColor = True
        '
        'btnadd
        '
        Me.btnadd.Location = New System.Drawing.Point(197, 328)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(75, 23)
        Me.btnadd.TabIndex = 13
        Me.btnadd.Text = "Añadir"
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'ckbActivate
        '
        Me.ckbActivate.AutoSize = True
        Me.ckbActivate.Location = New System.Drawing.Point(188, 213)
        Me.ckbActivate.Name = "ckbActivate"
        Me.ckbActivate.Size = New System.Drawing.Size(15, 14)
        Me.ckbActivate.TabIndex = 12
        Me.ckbActivate.UseVisualStyleBackColor = True
        '
        'txtbhome
        '
        Me.txtbhome.Location = New System.Drawing.Point(188, 173)
        Me.txtbhome.MaxLength = 150
        Me.txtbhome.Name = "txtbhome"
        Me.txtbhome.Size = New System.Drawing.Size(187, 20)
        Me.txtbhome.TabIndex = 9
        '
        'txtbname
        '
        Me.txtbname.Location = New System.Drawing.Point(188, 143)
        Me.txtbname.MaxLength = 100
        Me.txtbname.Name = "txtbname"
        Me.txtbname.Size = New System.Drawing.Size(187, 20)
        Me.txtbname.TabIndex = 8
        '
        'lblc2
        '
        Me.lblc2.AutoSize = True
        Me.lblc2.Location = New System.Drawing.Point(87, 278)
        Me.lblc2.Name = "lblc2"
        Me.lblc2.Size = New System.Drawing.Size(66, 13)
        Me.lblc2.TabIndex = 7
        Me.lblc2.Text = "Cuenta nº 2:"
        '
        'lblc1
        '
        Me.lblc1.AutoSize = True
        Me.lblc1.Location = New System.Drawing.Point(87, 245)
        Me.lblc1.Name = "lblc1"
        Me.lblc1.Size = New System.Drawing.Size(66, 13)
        Me.lblc1.TabIndex = 6
        Me.lblc1.Text = "Cuenta nº 1:"
        '
        'lvlActivate
        '
        Me.lvlActivate.AutoSize = True
        Me.lvlActivate.Location = New System.Drawing.Point(87, 213)
        Me.lvlActivate.Name = "lvlActivate"
        Me.lvlActivate.Size = New System.Drawing.Size(43, 13)
        Me.lvlActivate.TabIndex = 5
        Me.lvlActivate.Text = "Activar:"
        '
        'lblhome
        '
        Me.lblhome.AutoSize = True
        Me.lblhome.Location = New System.Drawing.Point(87, 176)
        Me.lblhome.Name = "lblhome"
        Me.lblhome.Size = New System.Drawing.Size(52, 13)
        Me.lblhome.TabIndex = 4
        Me.lblhome.Text = "Domicilio:"
        '
        'lblname
        '
        Me.lblname.AutoSize = True
        Me.lblname.Location = New System.Drawing.Point(87, 146)
        Me.lblname.Name = "lblname"
        Me.lblname.Size = New System.Drawing.Size(47, 13)
        Me.lblname.TabIndex = 3
        Me.lblname.Text = "Nombre:"
        '
        'txtbcif
        '
        Me.txtbcif.Location = New System.Drawing.Point(188, 105)
        Me.txtbcif.MaxLength = 9
        Me.txtbcif.Name = "txtbcif"
        Me.txtbcif.Size = New System.Drawing.Size(187, 20)
        Me.txtbcif.TabIndex = 2
        '
        'lblcif
        '
        Me.lblcif.AutoSize = True
        Me.lblcif.Location = New System.Drawing.Point(87, 108)
        Me.lblcif.Name = "lblcif"
        Me.lblcif.Size = New System.Drawing.Size(26, 13)
        Me.lblcif.TabIndex = 1
        Me.lblcif.Text = "CIF:"
        '
        'lblTittle
        '
        Me.lblTittle.AutoSize = True
        Me.lblTittle.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTittle.Location = New System.Drawing.Point(158, 10)
        Me.lblTittle.Name = "lblTittle"
        Me.lblTittle.Size = New System.Drawing.Size(166, 25)
        Me.lblTittle.TabIndex = 0
        Me.lblTittle.Text = "Añadir Empresa"
        '
        'AnadirEmpresa
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1366, 738)
        Me.Controls.Add(Me.pnlAdd)
        Me.Name = "AnadirEmpresa"
        Me.Text = "AñadirEmpresa"
        Me.Controls.SetChildIndex(Me.pnlAdd, 0)
        Me.pnlAdd.ResumeLayout(False)
        Me.pnlAdd.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents pnlAdd As Panel
    Friend WithEvents lblTittle As Label
    Friend WithEvents ckbActivate As CheckBox
    Friend WithEvents txtbhome As TextBox
    Friend WithEvents txtbname As TextBox
    Friend WithEvents lblc2 As Label
    Friend WithEvents lblc1 As Label
    Friend WithEvents lvlActivate As Label
    Friend WithEvents lblhome As Label
    Friend WithEvents lblname As Label
    Friend WithEvents txtbcif As TextBox
    Friend WithEvents lblcif As Label
    Friend WithEvents btnclean As Button
    Friend WithEvents btnreturn As Button
    Friend WithEvents btnadd As Button
    Friend WithEvents cmbaccount2 As ComboBox
    Friend WithEvents cmbaccount1 As ComboBox
End Class
